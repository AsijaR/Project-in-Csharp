﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Text.RegularExpressions;
using eStud.Model;

namespace eStud
{
    /// <summary>
    /// Interaction logic for PodnesiZahtev.xaml
    /// </summary>
    public partial class PodnesiZahtev : UserControl
    {
        Student student;
        public PodnesiZahtev(Student s)
        {
            student = s;
            InitializeComponent();
            
        }
        public void popuniPrijavu()
        {
           

        }

        private void btnPosalji_Click(object sender, RoutedEventArgs e)
        {

        }
        private void tbBrtelefona_previewtext(object sender, TextCompositionEventArgs e)
        {   //Onemogucava korisnku da unese slova. Ima dozvolu da unese samo za brojeve
            e.Handled = new Regex("[^0-9]+").IsMatch(e.Text);
        }

    }
}
