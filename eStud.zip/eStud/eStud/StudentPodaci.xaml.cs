﻿using eStud.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace eStud
{
    /// <summary>
    /// Interaction logic for StudentPodaci.xaml
    /// </summary>
    public partial class StudentPodaci : UserControl
    {
        public DataTable rezultati;
        bool state = false;
        public StudentPodaci()
        {
            InitializeComponent();
            popuniTabelu();
        }
        public void popuniTabelu()
        {
           rezultati = DBController.PodaciStudent();
           TabelaStudenti.ItemsSource = rezultati.DefaultView;
        }

        private void btnDodajStud_Click(object sender, RoutedEventArgs e)
        {
            if (state == true)
            {
                pnlDodajStud.Children.Clear();
                state = false;
            }
            else
            {
                pnlDodajStud.Children.Clear();
                DodajStudenta df = new DodajStudenta(TabelaStudenti);
                pnlDodajStud.Children.Add(df);
                state = true;
            }
        }
        private void btnIzbrisi_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                MessageBoxResult result = MessageBox.Show("Da li ste sigurni", "Confirmation", MessageBoxButton.YesNo);
                if (result == MessageBoxResult.Yes)
                {
                    //TabelaReferenti.SelectedItem;
                    TabelaStudenti.CanUserDeleteRows = true;

                    DataRowView row = (DataRowView)TabelaStudenti.SelectedItems[0];
                    DBController.izbrisiKorisnika(row["username"].ToString());
                    rezultati.Rows.Remove(row.Row);
                    //  MessageBox.Show(TabelaReferenti.SelectedItem.ToString());
                    //PopuniTabelu();
                }
            }
            catch (Exception ex)
            {

            }
        }
        private void btnIzmeni_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
