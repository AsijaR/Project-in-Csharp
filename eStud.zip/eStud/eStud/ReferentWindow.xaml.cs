﻿using eStud.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace eStud
{
    /// <summary>
    /// Interaction logic for ReferentWindow.xaml
    /// </summary>
    public partial class ReferentWindow : Window
    {
        private Referent r;
        public ReferentWindow(Korisnik k)
        {
            this.r = new Referent(k);
            InitializeComponent();
            this.ime.Content = this.r.getIme() + " " + this.r.getPrezime();
        }
        private void btnPodaci_Click(object sender, RoutedEventArgs e)
        {
            GlavniPanel.Children.Clear(); //brisemo ono sto se nalazi u panelu
            PodaciReferent rp = new PodaciReferent(r);
            GlavniPanel.Children.Add(rp);   //Dodajemo ono sto smo napravili u podacireferent.xaml prozoru

        }
        private void btnOdjava_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            MainWindow mw = new MainWindow();
            mw.ShowDialog();
        }


        private void btnZahteviIspit_Click(object sender, RoutedEventArgs e)
        {
            this.GlavniPanel.Children.Clear();
            ReferentZahteviPrijava rzp = new ReferentZahteviPrijava();
            this.GlavniPanel.Children.Add(rzp);
        }

        private void BtnKreiranePrijavnice_Click(object sender, RoutedEventArgs e)
        {
            this.GlavniPanel.Children.Clear();
            KreirajPrijavnicu kp = new KreirajPrijavnicu(r);
            this.GlavniPanel.Children.Add(kp);
        }
    }
}
