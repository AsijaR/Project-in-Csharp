﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using eStud.Model;

namespace eStud
{
    /// <summary>
    /// Interaction logic for KreirajPrijavnicu.xaml
    /// </summary>
    public partial class KreirajPrijavnicu : UserControl
    {   Referent referent;
        public KreirajPrijavnicu(Referent r)
        { referent= r;
            InitializeComponent();
        }

       
        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
               Prijavnica p = new Prijavnica();
                p.Load(@"Prijavnica.rep");
                Pregled.ViewerCore.ReportSource = p;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
                
        }
    }
}
