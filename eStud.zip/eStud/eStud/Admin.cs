﻿using eStud.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eStud
{
    public class Admin : Korisnik
    {
        public Admin(string username, string usertype, string ime, string prezime, string datumRodjenja, string pol) : base(username, usertype, ime, prezime, datumRodjenja, pol)
        {

        }
        public Admin(Korisnik k) : base(k.getUserName(), k.getUserType(), k.getIme(), k.getPrezime(), k.getDatumRodjenja(), k.getPol())
        {

        }

    }
}

